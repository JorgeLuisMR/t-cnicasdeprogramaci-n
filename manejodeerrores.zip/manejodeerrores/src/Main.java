import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n1, res;

        try {
            System.out.print("ingresar valor: ");
            n1 = teclado.nextInt();
            teclado.nextLine();
            res = n1 / 0;

            System.out.print("El valor es: " + res);

        } catch (Exception ex) {

            System.out.println("Error" + ex.getMessage());

        }
        finally {
            System.out.println("FIN - FINAlly");
        }

    }

}
