
public class Operaciones {
    public Operaciones() {
    }               
    public int suma(int a, int b){
        System.out.println("Suma 1");
        return a + b;
    }
                     
    public double suma(double a, double b){
        System.out.println("Suma 2");
        return a + b;
    }
    
    public double suma(int a, double b){
        System.out.println("Suma 3");
        return a + b;
    }
}

