
public class Main {
    public static void main(String[] args) {
        Operaciones op = new Operaciones();
        System.out.println(op.suma(1, 2));
        System.out.println(op.suma(1.5, 2.5));
        System.out.println(op.suma(1, 2.5));
        System.out.println(op.suma('@', 1));
    }
    
}